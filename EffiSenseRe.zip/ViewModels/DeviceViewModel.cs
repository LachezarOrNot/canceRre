﻿namespace EffiSenseRe.ViewModels {
    public class DeviceViewModel {
        public string Name { get; set; }
        public double AnnualEnergyConsumption { get; set; }
        public string Category { get; set; }
    }
}
